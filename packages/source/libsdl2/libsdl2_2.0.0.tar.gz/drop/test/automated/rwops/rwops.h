/**
 * Part of SDL test suite.
 *
 * Written by Edgar Simo "bobbens"
 *
 * Released under Public Domain.
 */


#ifndef _TEST_RWOPS
#  define _TEST_RWOPS


int test_rwops (void);


#endif /* _TEST_RWOPS */

