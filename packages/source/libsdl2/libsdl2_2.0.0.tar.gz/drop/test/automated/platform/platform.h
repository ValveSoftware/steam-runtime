/**
 * Part of SDL test suite.
 *
 * Written by Edgar Simo "bobbens"
 *
 * Released under Public Domain.
 */


#ifndef _TEST_PLATFORM
#  define _TEST_PLATFORM


int test_platform (void);


#endif /* _TEST_PLATFORM */

